function EditProfile() {
    <div className="profile">
    <nav className="navbar">
      <ul className="navbar-menu">
        <li className="navbar-item active">Home</li>
        <li className="navbar-item">Messages</li>
        <li className="navbar-item">Jobs</li>
        <li className="navbar-item">My Network</li>
        <li className="navbar-item">Notifications</li>
      </ul>
    </nav>
    </div>
}

export default EditProfile;